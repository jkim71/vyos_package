var searchData=
[
  ['pfx_5frecord_0',['pfx_record',['../structpfx__record.html',1,'']]],
  ['pfx_5ftable_1',['pfx_table',['../structpfx__table.html',1,'']]]
];
