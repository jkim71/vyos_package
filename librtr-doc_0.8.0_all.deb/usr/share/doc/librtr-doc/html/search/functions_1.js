var searchData=
[
  ['pfx_5ftable_5fadd_0',['pfx_table_add',['../group__mod__pfx__h.html#gaae469c2eac68b697dfa4128e1c2ff792',1,'pfx.h']]],
  ['pfx_5ftable_5ffor_5feach_5fipv4_5frecord_1',['pfx_table_for_each_ipv4_record',['../group__mod__pfx__h.html#gac22895fe1d7d1de65003de76399be48d',1,'pfx.h']]],
  ['pfx_5ftable_5ffor_5feach_5fipv6_5frecord_2',['pfx_table_for_each_ipv6_record',['../group__mod__pfx__h.html#ga06d1f95df3a8952bced60588d52bc51e',1,'pfx.h']]],
  ['pfx_5ftable_5ffree_3',['pfx_table_free',['../group__mod__pfx__h.html#gaf31f339bbca6180da436a43d0bd17d10',1,'pfx.h']]],
  ['pfx_5ftable_5finit_4',['pfx_table_init',['../group__mod__pfx__h.html#ga1c2751808568eef03338a9905a0735ff',1,'pfx.h']]],
  ['pfx_5ftable_5fremove_5',['pfx_table_remove',['../group__mod__pfx__h.html#ga2f03e320b7d228e7861413b8007e8648',1,'pfx.h']]],
  ['pfx_5ftable_5fsrc_5fremove_6',['pfx_table_src_remove',['../group__mod__pfx__h.html#gabcdf5278a027b9e6e1051eb1ecfac782',1,'pfx.h']]],
  ['pfx_5ftable_5fvalidate_7',['pfx_table_validate',['../group__mod__pfx__h.html#ga24a6236cd78f9708c089793c02eb693f',1,'pfx.h']]],
  ['pfx_5ftable_5fvalidate_5fr_8',['pfx_table_validate_r',['../group__mod__pfx__h.html#gadc7e5454793c8c69724a72a14ffe0f3b',1,'pfx.h']]]
];
