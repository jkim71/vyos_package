var searchData=
[
  ['prefix_20validation_20table_0',['Prefix validation table',['../group__mod__pfx__h.html',1,'']]]
];
