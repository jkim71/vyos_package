var searchData=
[
  ['rtr_20connection_20manager_0',['RTR connection manager',['../group__mod__rtr__mgr__h.html',1,'']]],
  ['rtr_20socket_1',['RTR socket',['../group__mod__rtr__h.html',1,'']]]
];
