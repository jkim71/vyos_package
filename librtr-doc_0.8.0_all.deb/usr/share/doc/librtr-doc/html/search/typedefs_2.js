var searchData=
[
  ['spki_5fupdate_5ffp_0',['spki_update_fp',['../group__mod__spki__h.html#ga208a2bec5211e883b44ebe693a1c5e5d',1,'spkitable.h']]]
];
